# Flutter responsive dashboard / admin panel UI

Supports for Mobile/Web/Windows/Mac/Linux app.

CI/CD Tool: Codemagic

Live demo: https://flutter-dashboard.codemagic.app/#/

UI reference: https://dribbble.com/shots/20572883-Fitness-Dashboard-UI-Design  

## Screenshot
