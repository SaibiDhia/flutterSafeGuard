import 'package:flutter/material.dart';

const primaryColorCode = 0xFFA9DFD8;
const cardBackgroundColor = Color(0xFF21222D);
