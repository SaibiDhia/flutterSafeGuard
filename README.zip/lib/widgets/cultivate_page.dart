import 'package:flutter/material.dart';

class CultivatePage extends StatefulWidget {
  const CultivatePage({Key? key}) : super(key: key);

  @override
  _CultivatePageState createState() => _CultivatePageState();
}

class _CultivatePageState extends State<CultivatePage> {
  // Add your class logic and methods here

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cultivate Plant'),
        backgroundColor: const Color(0xFF171821),
      ),
      body: Center(
        child: Card(
          margin: const EdgeInsets.all(16.0),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Text(
                  'Welcome to Cultivate Page! This is a cultivate page.',
                  style: TextStyle(fontSize: 18.0),
                ),
                SizedBox(height: 16.0),
                // Add more widgets within the card if needed
              ],
            ),
          ),
        ),
      ),
    
    );
  }
}

